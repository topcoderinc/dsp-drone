local MAXPOINTS = 92
local index = 0
local altitudes = {}
local launches = {}
local lastTime = 0
local lastTimerValue = 0
local lastMaxAltitude = 0
local time
local altitude
local timer

local function init()
	lcd.drawPixmap(145, 30, "/bmp/PX4.bmp")
end

local function background()
end

local function run(event)

	local fm = 0
	local s1 = getValue("sa")
	local s2 = getValue("sb")
	if s2 == -1024 then
		if s1 == -1024 then
			fm = "Manual"
		end
		if s1 == 0 then
			fm = "Acro"
		end
		if s1 == 1024 then
			fm = "Altitude"
		end
	end

	if s2 == 0 then
		if s1 == -1024 then
			fm = "Position"
		end
		if s1 == 0 then
			fm = "Mission"
		end
		if s1 == 1024 then
			fm = "Hold"
		end
	end

	if s2 == 1024 then
		if s1 == -1024 then
			fm = "Return"
		end
		if s1 == 0 then
			fm = "Offboard"
		end
		if s1 == 1024 then
			fm = 9
		end
	end


	lcd.clear()
	lcd.drawText(2, 2, "PX4 Flight Info                                            ", INVERS)
	-- lcd.drawPixmap(145, 30, "/bmp/PX4.bmp")
	lcd.drawText(2, 14, "Flight Mode: " .. fm)
	if (getValue("sf")) == 1024 then
		lcd.drawText(188,14, "Hold", INVERS)
	end
end

return { init=init, background=background, run=run }