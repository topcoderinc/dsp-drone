local inputs = {
								 { "3PSwitch1", SOURCE },
								 { "3PSwitch2", SOURCE },
								 { "Override", SOURCE }
							 }
								 
local outputs = { "Output" }

local function run(s1, s2, o) -- Values of channels are -1024 to 1024 (not percent)
	if o == 1024 then
		return 256
	end

	if s2 == -1024 then
		if s1 == -1024 then
			return -1024
		end
		if s1 == 0 then
			return -768
		end
		if s1 == 1024 then
			return -512
		end
	end

	if s2 == 0 then
		if s1 == -1024 then
			return -256
		end
		if s1 == 0 then
			return 0
		end
		if s1 == 1024 then
			return 256
		end
	end

	if s2 == 1024 then
		if s1 == -1024 then
			return 512
		end
		if s1 == 0 then
			return 768
		end
		if s1 == 1024 then
			return 1024
		end
	end

end

return { input=inputs, output=outputs, run=run }